let tasks = JSON.parse(localStorage.getItem("tasks")) || [];
let currentFilter = "all";

const input = document.getElementById("taskInput");
const addBtn = document.getElementById("addBtn");
const list = document.getElementById("taskList");

function saveTasks(){
localStorage.setItem("tasks", JSON.stringify(tasks));
}

function render(){
list.innerHTML="";

let filtered = tasks.filter(task=>{
if(currentFilter==="active") return !task.completed;
if(currentFilter==="completed") return task.completed;
return true;
});

filtered.forEach(task=>{
let li=document.createElement("li");

li.innerHTML = `
<span class="${task.completed?'completed':''}">${task.text}</span>
<div>
<button class="complete" data-id="${task.id}">Done</button>
<button class="delete" data-id="${task.id}">Delete</button>
</div>
`;

list.appendChild(li);
});
}

addBtn.onclick=()=>{
if(input.value.trim()){
tasks.push({
id:Date.now(),
text:input.value,
completed:false
});
input.value="";
saveTasks();
render();
}
};

list.addEventListener("click",e=>{
let id=Number(e.target.dataset.id);

if(e.target.classList.contains("delete")){
tasks=tasks.filter(t=>t.id!==id);
}

if(e.target.classList.contains("complete")){
let task=tasks.find(t=>t.id===id);
task.completed=!task.completed;
}

saveTasks();
render();
});

document.querySelector(".filters").addEventListener("click",e=>{
currentFilter=e.target.dataset.filter;
render();
});

render();
